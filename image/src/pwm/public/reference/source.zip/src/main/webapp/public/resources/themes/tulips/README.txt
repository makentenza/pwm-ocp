This is an example custom style.

Edit the css stylesheets to fit your needs. Any style defined
in these files will override the default stayles.

The example logo has been composed using a file from www.clker.com:
http://www.clker.com/clipart-12291.html
